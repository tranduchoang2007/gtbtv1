 <?php 
// code được viết bởi to9xvn
// trang web: http://dailysieure.com/
// liên hệ: http://dailysieure.com/to9xvn
// Vui lòng không xoá và tôn trọng tác giả làm ra nó
?><!-- Footer -->
                    <footer class="footer">© 2021 Vận Hành Bởi <a href="https://www.facebook.com/ngocminhvn/">NgocMinhVn</a></footer>
</body>

</html>